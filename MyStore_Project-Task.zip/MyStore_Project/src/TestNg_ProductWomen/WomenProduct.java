package TestNg_ProductWomen;

import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.record.CountryRecord;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class WomenProduct {
	WebDriver w;
//	Home h=w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[1]/a[1]/i[1]")).click();
	@Test
  public void WomentAction() throws InterruptedException {
	  w.get("http://automationpractice.com/index.php");
	  w.manage().window().maximize();
	  Actions women=new Actions(w);
	  women.moveToElement(w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/div[3]/div[1]/div[1]/div[6]/ul[1]/li[1]/a[1]"))).build().perform();
		w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/div[3]/div[1]/div[1]/div[6]/ul[1]/li[1]/ul[1]/li[1]/ul[1]/li[1]/a[1]")).click();
		Thread.sleep(2000);
//		w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[3]/div[2]/ul[1]/li[1]/div[1]/div[1]/div[1]/a[1]/img[1]")).click();
		Actions img=new Actions(w);
		img.moveToElement(w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[3]/div[2]/ul[1]/li[1]/div[1]/div[1]/div[1]/a[1]/img[1]"))).build().perform();
		w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[3]/div[2]/ul[1]/li[1]/div[1]/div[2]/div[2]/a[1]/span[1]")).click();
		WebElement element = w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/div[3]/div[1]/div[1]/div[4]/div[1]/div[1]/span[1]"));
		if (element.isDisplayed() && element.isEnabled()) {
		    element.click();
		}
//		  BLOUSE
		
		Thread.sleep(1000);
		 Actions womenblou=new Actions(w);
		  womenblou.moveToElement(w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/div[3]/div[1]/div[1]/div[6]/ul[1]/li[1]/a[1]"))).build().perform();
		  w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/div[3]/div[1]/div[1]/div[6]/ul[1]/li[1]/ul[1]/li[1]/ul[1]/li[2]/a[1]")).click();

		  Actions blouImg = new Actions(w);
		  blouImg.moveToElement(w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[3]/div[2]/ul[1]/li[1]/div[1]/div[1]/div[1]/a[1]/img[1]"))).build().perform();
		  w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[3]/div[2]/ul[1]/li[1]/div[1]/div[2]/div[2]/a[1]/span[1]")).click();
//		 Search CASUAL DRESSES
//		  Actions dresses=new Actions(w);
//		  dresses.moveToElement(w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/div[3]/div[1]/div[1]/div[6]/ul[1]/li[2]/a[1]"))).build().perform();
//		  w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/div[3]/div[1]/div[1]/div[6]/ul[1]/li[2]/ul[1]/li[1]/a[1]")).click();
		  w.findElement(By.xpath("//input[@id='search_query_top']")).sendKeys("CASUAL DRESSES");
		  w.findElement(By.xpath("//header/div[3]/div[1]/div[1]/div[2]/form[1]/button[1]")).click();
//		  w.findElement(By.xpath("//input[@id='layered_id_feature_18']")).click();
		  Actions casualDressImg=new Actions(w);
		  casualDressImg.moveToElement(w.findElement(By.xpath("//body/div[@id='page']/div[2]/div[1]/div[3]/div[2]/ul[1]/li[1]/div[1]/div[1]/div[1]/a[1]/img[1]"))).build().perform();
		  w.findElement(By.xpath("//body/div[@id='page']/div[2]/div[1]/div[3]/div[2]/ul[1]/li[1]/div[1]/div[2]/div[2]/a[1]/span[1]")).click();
		  WebElement element1 = w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/div[3]/div[1]/div[1]/div[4]/div[1]/div[1]/span[1]"));
			if (element1.isDisplayed() && element1.isEnabled()) {
			    element1.click();
			}
//			EVENING DRESSES
			Actions dresses1=new Actions(w);
			dresses1.moveToElement(w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/div[3]/div[1]/div[1]/div[6]/ul[1]/li[2]/a[1]"))).build().perform();
			  w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/div[3]/div[1]/div[1]/div[6]/ul[1]/li[2]/ul[1]/li[2]/a[1]")).click();
			  Actions eveningDressImg=new Actions(w);
			  eveningDressImg.moveToElement(w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[3]/div[2]/ul[1]/li[1]/div[1]/div[1]/div[1]/a[1]/img[1]"))).build().perform();
			  w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[3]/div[2]/ul[1]/li[1]/div[1]/div[2]/div[2]/a[1]/span[1]")).click();
			  WebElement element2 = w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/div[3]/div[1]/div[1]/div[4]/div[1]/div[1]/span[1]"));
				if (element2.isDisplayed() && element2.isEnabled()) {
					element2.click();
				}
				w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[1]/a[1]/i[1]")).click();
//				SUMMER DRESSES
				Actions dresses2=new Actions(w);
				dresses2.moveToElement(w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/div[3]/div[1]/div[1]/div[6]/ul[1]/li[2]/a[1]"))).build().perform();
				  w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/div[3]/div[1]/div[1]/div[6]/ul[1]/li[2]/ul[1]/li[3]/a[1]")).click();
				  Actions SummerDressImg=new Actions(w);
				  SummerDressImg.moveToElement(w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[3]/div[2]/ul[1]/li[1]/div[1]/div[1]/div[1]"))).build().perform();
				  w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[3]/div[2]/ul[1]/li[1]/div[1]/div[2]/div[2]/a[1]/span[1]")).click();
				  WebElement element3 = w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/header[1]/div[3]/div[1]/div[1]/div[4]/div[1]/div[1]/span[1]"));
					if (element3.isDisplayed() && element3.isEnabled()) {
					    element3.click();
					}
				w.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
//				CATEGORY
//				  WebElement checkBoxElement = w.findElement(By.xpath("/html[1]/body[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[2]/div[1]/form[1]/div[1]/div[1]/ul[1]/li[1]/div[1]/span[1]/input[1]']"));
//				  boolean isSelected = checkBoxElement.isSelected();
//				  		
//				  //performing click operation if element is not checked
//				  if(isSelected == false) {
//				  	checkBoxElement.click();
//				  }
				
//				CART
				w.findElement(By.xpath("//header/div[3]/div[1]/div[1]/div[3]/div[1]/a[1]")).click();
//				w.findElement(By.xpath("//tbody/tr[@id='product_1_1_0_0']/td[7]/div[1]/a[1]/i[1]")).click();
				w.findElement(By.xpath("//a[contains(text(),'Sign in')]")).click();
				
				Thread.sleep(2000);
				

//				Signup
//				@Test
//				public void SignUp() throws InterruptedException {
//				w.findElement(By.xpath("//input[@id='email_create']")).sendKeys("saranyarangaraj227@gmail.com");
//				w.findElement(By.xpath("//body/div[@id='page']/div[2]/div[1]/div[3]/div[1]/div[1]/div[1]/form[1]/div[1]/div[3]/button[1]/span[1]")).click();
//				w.findElement(By.xpath("//input[@id='id_gender2']")).click();
//				w.findElement(By.xpath("//input[@id='customer_firstname']")).sendKeys("Divya");
//				w.findElement(By.xpath("//input[@id='customer_lastname']")).sendKeys("Raja");
//				w.findElement(By.xpath("//input[@id='passwd']")).sendKeys("Sara227@");
////				w.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
////				WebDriverWait wait=new WebDriverWait(w, 20);
//				Thread.sleep(2000);
//				
//				WebElement date_drp = w.findElement(By.xpath("//select[@id='days']"));
//				Select date = new Select(date_drp);
//				date.selectByIndex(6);
//				WebElement month_drp = w.findElement(By.xpath("//select[@id='months']"));
//				Select month = new Select(month_drp);
//				month.selectByIndex(7);	
//				WebElement year_drp = w.findElement(By.xpath("//select[@id='years']"));
//				Select year = new Select(year_drp);
//				year.selectByIndex(20);	
//				
//				
//				w.findElement(By.xpath("//input[@id='firstname']")).sendKeys("Divya");
//				w.findElement(By.xpath("//input[@id='lastname']")).sendKeys("Raja");
//				w.findElement(By.xpath("//input[@id='company']")).sendKeys("ABC&Co");
//				w.findElement(By.xpath("//input[@id='address1']")).sendKeys("Egmore");
//				w.findElement(By.xpath("//input[@id='address2']")).sendKeys("Xy Street");
//				w.findElement(By.xpath("//input[@id='city']")).sendKeys("Chennai");
//			Select state= new Select(w.findElement(By.xpath("//select[@id='id_state']")));
//			state.selectByVisibleText("Indiana");
//			w.findElement(By.xpath("//input[@id='postcode']")).sendKeys("12345");
//			Select country=new Select(w.findElement(By.xpath("//select[@id='id_country']")));
//			country.selectByVisibleText("United States");
//			w.findElement(By.xpath("//textarea[@id='other']")).sendKeys("Other Area");
//			w.findElement(By.xpath("//input[@id='phone']")).sendKeys("9874563210");
//			w.findElement(By.xpath("//input[@id='phone_mobile']")).sendKeys("9632587410");
//			w.findElement(By.xpath("//input[@id='alias']")).sendKeys("Chennai");
//			w.findElement(By.xpath("//button[@id='submitAccount']")).click();
//				w.findElement(By.xpath("//body/div[@id='page']/div[2]/div[1]/div[1]/a[1]/i[1]")).click();
				
			
//				w.close();
				
			 
  
//	CONTACTUS
		w.findElement(By.xpath("//header/div[2]/div[1]/div[1]/nav[1]/div[2]/a[1]")).click();
		Select sub= new Select(w.findElement(By.xpath("//select[@id='id_contact']")));
		sub.selectByVisibleText("Customer service");
		w.findElement(By.xpath("//input[@id='email']")).sendKeys("saranyarangaraj227@gmail.com");
		w.findElement(By.xpath("//input[@id='id_order']")).sendKeys("xyza");
		w.findElement(By.xpath("//textarea[@id='message']")).sendKeys("Order details");
		w.findElement(By.xpath("//button[@id='submitMessage']")).click();
		w.findElement(By.xpath("//body/div[@id='page']/div[2]/div[1]/div[1]/a[1]")).click();
		
//		INFORMATION
//		Specials
		w.findElement(By.xpath("//a[contains(text(),'Specials')]")).click();
		Select spl=new Select(w.findElement(By.xpath("//select[@id='selectProductSort']")));
		spl.selectByVisibleText("Reference: Highest first");
		w.findElement(By.xpath("//body/div[@id='page']/div[2]/div[1]/div[3]/div[2]/ul[1]/li[1]/div[1]/div[1]/div[1]")).click();
//		New Products
		w.findElement(By.xpath("//a[contains(text(),'New products')]")).click();
		w.findElement(By.xpath("//body/div[@id='page']/div[2]/div[1]/div[1]/a[1]")).click();
		w.close();
	}
  @BeforeMethod
  public void beforeMethod() {
	System.setProperty("webdriver.chrome.driver","C:\\\\Users\\\\saran\\\\OneDrive\\\\Desktop\\\\Selenium\\\\chromedriver_win32\\\\chromedriver.exe");
	  //System.setProperty("webdriver.gecko.driver", "C:\\Users\\saran\\OneDrive\\Desktop\\Selenium\\geckodriver.exe");
	 w=new ChromeDriver();
  
}
}
